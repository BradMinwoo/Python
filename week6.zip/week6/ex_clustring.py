from sklearn import datasets
import pandas as pd
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

iris = datasets.load_iris()
labels = pd.DataFrame(iris.target)
labels.columns = ['labels']
data = pd.DataFrame(iris.data)
data.columns=['Sepal length', 'Sepal width','Petal length', 'Petal width']
data = pd.concat([data, labels], axis=1)
feature = data[['Sepal length', 'Sepal width']]

model = KMeans(n_clusters=3, algorithm='auto') # 군집 3개
model.fit(feature)
pred = pd.DataFrame(model.predict(feature))
pred.columns = ['predict']

plt.scatter(feature['Sepal length'], feature['Sepal width'])
plt.show()

r = pd.concat([feature, pred], axis=1)
plt.scatter(r['Sepal length'], r['Sepal width'], c=r['predict'], alpha=0.5)
centers= pd.DataFrame(model.cluster_centers_, columns=['Sepal length', 'Sepal width'])
center_x = centers['Sepal length']
center_y = centers['Sepal width']
plt.scatter(center_x, center_y, s=50, marker='D', c='r')
plt.show()