from sklearn import datasets
import pandas as pd
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

df = pd.read_csv('./Mall_Customers1.csv')
feature = df.iloc[:,[3,4]].values
print(feature)

model = KMeans(n_clusters=5, init='k-means++'
               ,max_iter=300, n_init=5, random_state=0)
predict = model.fit_predict(feature)

plt.scatter(feature[predict == 0, 0], feature[predict ==0, 1], s=100, c='pink', label='miser')
plt.scatter(feature[predict == 1, 0], feature[predict ==1, 1], s=100, c='yellow', label='general')
plt.scatter(feature[predict == 2, 0], feature[predict ==2, 1], s=100, c='cyan', label='target')
plt.scatter(feature[predict == 3, 0], feature[predict ==3, 1], s=100, c='magenta', label='spendthrift')
plt.scatter(feature[predict == 4, 0], feature[predict ==4, 1], s=100, c='orange', label='careful')
plt.scatter(model.cluster_centers_[:,0], model.cluster_centers_[:,1], s=50 , c='blue',label='center')

plt.style.use('fivethirtyeight')
plt.title('K means clustering', fontsize = 20)
plt.ylabel('sending score')
plt.xlabel('annual income')
plt.legend()
plt.grid()
plt.show()