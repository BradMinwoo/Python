import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules
#pip install mlxtend
import os
print(os.getcwd())
data = pd.read_csv('/home/pc11/PycharmProjects/pythonProject/week6/data/chipotle.csv', sep=',')
print(data.info())
dataset = data[['order_id','item_name']]
print(dataset.head())
#주문수
group_num = dataset['order_id'].unique().size
item_list = []
for i in range(group_num):
    itemset = set()
    order = dataset[dataset['order_id'] == i+1]
    for index, row in order.iterrows():
        itemset.add(order['item_name'][index])
    item_list.append(list(itemset))
print(item_list)
trans_encoder = TransactionEncoder()
te_array = trans_encoder.fit(item_list). transform(item_list)
matrix = pd.DataFrame(te_array, columns=trans_encoder.columns_)

frequent_item = apriori(matrix, min_support=0.05, use_colnames=True)
print(frequent_item)
asso = association_rules(frequent_item, metric='lift', min_threshold=1)
print(asso)