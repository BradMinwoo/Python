import requests

base_rul = "http://127.0.0.1:5050/"
# res = requests.get(base_rul + "helloworld")  # 린턴 받음 nm 없을때
res = requests.get(base_rul + "helloworld/nick")  # 린턴 받음 데이터 nm 이 있을 때
print(res.json()) # 리턴 받은값을 json형태로 출력.

