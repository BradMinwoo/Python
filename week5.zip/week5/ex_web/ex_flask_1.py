#pip install flask
from flask import Flask
#pip install flask_restful
from flask_restful import Api, Resource
from selenium.webdriver.common.devtools.v85.dom import Rect

app = Flask(__name__)
api = Api(app)



class HelloWorld(Resource):
    def get(self, nm):
        return {"data":nm+"Hellow World"}
    def put(self, nm):
        return {"data":nm+"Hellow World"}
api.add_resource(HelloWorld,"/helloworld/<string:nm>")

if __name__ =='__main__':
    app.run(debug=True, port=8080, host='0.0.0.0') # 포트가 충돌나면 다른 포드를 줘라,host 자기 ip씀


# @app.route('/')  #url 약힐..컨트롤러 맵핑 역할
# def helloword():
#     return "Hello Next It"
# if __name__ =='__main__':
#     #app.run()
#     #debug모드는 소스 반영시 restart 하지 않아도 됨
#     app.run(debug=True)
