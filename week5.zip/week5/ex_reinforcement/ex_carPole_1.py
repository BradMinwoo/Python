#pip install gym
import gym
env = gym.make('CartPole-v0')
#마찰이 없는 트랙에 카트 와 막대기
#action : 0 왼쪽, 1 오른쪽
#매 스텝 마닺 ㅔ대로 서있으면 +1
#수직으로 부터 막대기가 -12, 12도 이상 기울어 지면 종료
# 시간 스템이 200
for i_episode in range(20):
    observation = env.reset(     )
    for i in range(200):
        env.render()
        #막대기가 오른쪽으로 기울어지면 오른ㅉ고 힘주기
        if observation[2] >0:
            action = 1
        else:
            action =0
        # action = env.action_space.sample()
        observation, reward, done, info = env.step(action)
        if done:
            print(str(i +1) + ' 만큼 살았음')
            break
env.close()
