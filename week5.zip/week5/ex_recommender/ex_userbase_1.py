import pandas as pd
import numpy as np
df_ratings = pd.read_csv('ratings.csv')
df_movie = pd.read_csv('movies.csv')
df_ratings.drop('timestamp', axis=1, inplace=True)
user_movie_rating = pd.merge(df_ratings, df_movie, on='movieId')

user_movie = user_movie_rating.pivot_table('rating', index='userId', columns='title')
user_movie.fillna(0, inplace=True)

from sklearn.metrics.pairwise import cosine_similarity
user_base = cosine_similarity(user_movie)
print(user_base)
user_base = pd.DataFrame(data=user_base, index=user_movie.index, columns=user_movie.index)
print(user_base.head())


def get_user_item(id,userId):
    movie_list = user_movie_rating[user_movie_rating['userId']==id]
    user_watch = user_movie_rating[user_movie_rating['userId']==userId]
    movie_list = movie_list[~movie_list['movieId'].isin(user_watch['userId'].values.tolist())]
    five_recommend = movie_list.sort_values(by='rating', ascending=False)[:6]
    return five_recommend.title.tolist()

def get_user_based_collabor(id):
    mybest = user_movie_rating[user_movie_rating['userId'] ==  id].sort_values(by='rating', ascending=False)[:6]
    print('mybest', '='*100)
    print(mybest['title'])
    #r가가운 유저
    sim_user = user_base[id].sort_values(ascending=False)[:6]
    id_list = sim_user.index.tolist()[1:]
    print(id_list)
    data = []
    for i in id_list:
        print('user:'+str(i))
        item = get_user_item(i, id)
        data += item
    setItem = set(data)
    return setItem

while True:
    text = input('userid:')
    print(get_user_based_collabor(int(text)))