import pandas
import pandas as pd


df_ratings = pd.read_csv('ratings.csv')
df_movie = pd.read_csv('movies.csv')

print(df_movie.head())
print(df_ratings.head())
df_ratings.drop('timestamp', axis=1, inplace=True)

user_movie_rating = pd.merge(df_ratings, df_movie, on='movieId')
print(user_movie_rating.head())

movie_user_rating = user_movie_rating.pivot_table('rating', index='title', columns='userId')
print(movie_user_rating.head())
movie_user_rating.fillna(0, inplace=True)
print(movie_user_rating.head())


from sklearn.metrics.pairwise import  cosine_similarity
item_base = cosine_similarity(movie_user_rating)
item_base = pd.DataFrame(data=item_base, index=movie_user_rating.index, columns=movie_user_rating.index)
print(item_base.head())
def get_item_based_collabor(title):
    #유사도 높은 5개
    return item_base[title].sort_values(ascending=False)[:6] # 내림 차순으로 정렬

while True:
    try:
        text = input('좋아하는 영화 이름:')
        print(get_item_based_collabor(text))
    except Exception as e:
        pass
