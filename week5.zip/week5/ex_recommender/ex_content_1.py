import pandas as pd
df_rating = pd.read_csv('./ratings.csv')
df_movie = pd.read_csv('./movies.csv')
print(df_movie)
# r : 개별 영화 평점
# v : 개별 영화에 평점을 투표한 횟수
# m : 상위 250(다다름) 안에 들어야 하는 최소 투표
# c : 전체 영화에 대한 평균 평점
def weighted_rating(p_x, p_m, p_c):
                   #해당로우, 평점,
    p_v = p_x['cnt']
    p_r = p_x['avgScore']
    return (p_v / (p_v + p_m) * p_r) + (p_m / (p_m + p_v) * p_c)

# 상위 m
df_mv = df_rating[['movieId', 'rating']]
df_movie = pd.merge(df_movie, df_mv.groupby('movieId').mean(), right_on = 'movieId', left_index=True)
df_movie.rename(columns={'rating':'avgScore'}, inplace=True)
df_movie = pd.merge(df_movie, df_mv.groupby('movieId').count(), right_on='movieId', left_index=True)
df_movie.rename(columns={'rating':'cnt'}, inplace=True)
# 평점 상위
m = df_movie['cnt'].quantile(0.91)
m_data = df_movie.copy().loc[df_movie['cnt'] >= m]
c = m_data['avgScore'].mean()
print(m, c)
m_data['score'] =m_data.apply(weighted_rating, args=[m, c], axis=1) # apply 판다에스 함수를 더함. args 로우 마다 값을 넣어줌
print(m_data.head())

df_rating.drop('timestamp', axis = 1, inplace =True)
m_data['genres'] = m_data['genres'].apply(lambda x : x.replace('|',''))
from sklearn.feature_extraction. text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
count_vector = CountVectorizer(ngram_range=(1,1))
#장르 매트릭스 생성(단어를 백터화 및 카운팅)
c_vector_genres = count_vector.fit_transform(m_data['genres'])
genres_sim = cosine_similarity(c_vector_genres, c_vector_genres).argsort()[:,::-1]

def get_recommend(df, movie_title, top=20):
    target_movie_index = df[df['title'] == movie_title].index.values
    sim_index = genres_sim[target_movie_index, :top].reshape(-1)
    #본인제외
    sim_index = sim_index[sim_index!=target_movie_index]
    result = df.iloc[sim_index].sort_values('score', ascending=False)[:10]
    return result

print(m_data['title'])
while True:
    text = input('좋아하는 영화 장르는?:')
    data = get_recommend(m_data,movie_title=text)
    for i, v in data.iterrows():
        print(data.loc[i]['title'], "::", data.loc[i]['genres'])


# #-