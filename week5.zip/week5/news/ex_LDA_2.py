#newData
#정치(0), 경제(1), 사회(2), 생활/문화(3), 세계(4), 기술/IT(5), 스포츠(6)
import os
import re

import path as path
from gensim import corpora
import gensim

def fn_text(text):

    f = open('./newsData/all_new.txt', 'a',encoding='utf-8')
    with f:
        f.write(str(text))
        f.writelines('\n')
def fn_clean_text(text):
    # 텍스트에 포함되어 있는 특수 문자 제거
    try:
        text = re.sub(r"\n", " ", text)
        text = re.sub(r"\t", " ", text)
        text = re.sub('[-=+,#/\?:^$.@*○\"※~&%_ㆍ;!』\\‘\\’|\(\)\[\]\<\>`\'…》]', '', text)
        text = re.sub('[^ \u3131-\u3163\uac00-\ud7a3]+', '', text)
    except Exception as e:
        print(str(e))
        text = ''
    finally:
        return text

path = './newsData/'

dir_list = os.listdir(path)
for dir in dir_list:
    filepath = os.path.join(path,dir)
    if os.path.isdir(filepath):
        print(filepath)
        file_list = os.listdir(filepath)
        for file in file_list:
            try:
                with open(os.path.join(filepath, file),'r', encoding='utf-8') as f:
                    msg = ""
                    line = f.readlines()
                    for text in line:
                        if text != '\n':
                            msg += ' ' + text
                    fn_text(msg.strip())
                    print(line)
            except Exception as e:
                print(str(e))

