import gensim
from gensim import corpora
from ex_LDA_3 import fn_del
from konlpy.tag import Okt
# (1) 텍스트 로드
# (2) 전처리 및 명사 추출
# (3) Dictionary에서 index 맵핑

model = gensim.models.ldamodel.LdaModel.load('./lda_news.model')
print(model)
topic = model.print_topics(num_topics=8, num_words=10)
print(topic)


for i in topic:
    print('토픽: ',i)
test_text = ['카카오 핸드폰 닌텐도 스위치'
             ,'한정판에는 터치 디스플레이를 적용했다. 사용자는 스마트폰을 이용할 때처럼 손가락으로']

dictionary = corpora.Dictionary.load('./lda_news.model.id2word')
okt = Okt()
text_token = [fn_del(okt.nouns(doc)) for doc in test_text]
print(dictionary.doc2bow(text_token[0]))
corpus = [dictionary.doc2bow(text) for text in test_text]

t1 = model[dictionary.doc2bow(test_text[0])]
print(t1, '토픽에 속함')

t3 = model[dictionary.doc2bow(test_text[1])]
print(t3, '토픽에 속함')