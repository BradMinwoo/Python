from nltk.tokenize import RegexpTokenizer
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from gensim import corpora
import gensim
import nltk
nltk.download('stopwords')


# =======================================
# -- Data Set
# =======================================

doc_a = "Brocolli is good to eat. My brother likes to eat good brocolli, but not my mother."
doc_b = "My mother spends a lot of time driving my brother around to baseball practice."
doc_c = "Some health experts suggest that driving may cause increased tension and blood pressure."
doc_d = "I often feel pressure to perform well at school, but my mother never seems to drive my brother to do better."
doc_e = "Health professionals say that brocolli is good for your health."

word_tokenizer = RegexpTokenizer(r'\w+')
en_stop = set(stopwords.words('english'))
p_stemmer = PorterStemmer()
doc_set = [doc_a, doc_b,doc_c,doc_d,doc_e]
texts =[]
for i in doc_set:
    raw = i.lower()
    word_token = word_tokenizer.tokenize(raw)
    stopped_token = [i for i in word_token if not i in en_stop]
    stemmed_token = [p_stemmer.stem(i) for i in stopped_token]
    texts.append(stemmed_token)
print(texts)
print('word token','='*100)
word_dictionary = corpora.Dictionary(texts)

for word_dic in word_dictionary.items():
    print(word_dic)

corpus = [word_dictionary.doc2bow(text) for text in texts]

lda_model = gensim.models.ldamodel.LdaModel(corpus, num_topics=2, id2word=word_dictionary, passes=100)
print(lda_model)
topic = lda_model.print_topics(num_topics=2, num_words=10)
print(topic)

t1 = lda_model[word_dictionary.doc2bow(texts[0])]
print(t1, '토픽에 속함')

t3 = lda_model[word_dictionary.doc2bow(texts[2])]
print(t3, '토픽에 속함')

