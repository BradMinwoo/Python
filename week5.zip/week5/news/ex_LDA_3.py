
import os
import re

import path as path
from gensim import corpora
import gensim
from konlpy.tag import Okt

doc_ko=[]

with open('./newsData/all_new.txt','r', encoding='utf-8')as f:
    doc_ko = f.readlines()
def fn_del(text_list):
    return_text = []
    for i, v in enumerate(text_list):
        if len(v) !=1:
            return_text.append(v)
    return  return_text


okt=Okt()
# result = []
# for line in doc_ko:
#     text = okt.pos(line, norm = True, stem = True)
#     r =[]
#     try :
#         for word in text:
#             # 이모티콘, 조사와 같은 텍스트를 제외
#             if not word[1] in ['Josa', 'Eomi', 'Punctuation']:
#                 r.append(word[0])
#             rl = (" ".join(r)).strip()
#             result.append(rl)
#     except Exception as e:
#         print(str(e))
# print(result)
from gensim import corpora
texts_ko = [fn_del(okt.nouns(doc)) for doc in doc_ko]
word_dictionary = corpora.Dictionary(texts_ko)
print(word_dictionary)
corpus = [word_dictionary.doc2bow(text) for text in texts_ko]

lda_model = gensim.models.ldamodel.LdaModel(corpus, num_topics=8
                                            , id2word=word_dictionary, passes=100)
lda_model.save('./lda_news.model')
print(lda_model)
topic = lda_model.print_topics(num_topics=8, num_words=10)
print(topic)
# pos = lambda d:['/'.join(p) for p in okt.pod(d, stem=True, norm=True)]
# print(pos)

