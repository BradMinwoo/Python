from cryptography.hazmat.primitives.ciphers.algorithms import SEED
from keras.utils import pad_sequences
from keras.preprocessing.text import Tokenizer
import numpy as np
#간닿나 감성 분류
#텍스 리뷰 - 긍정 부정 예측
docs = ["너무 재밌네요"
        ,"최고예요"
        ,"참 잘 만든 영화예요"
        ,"한번 더 보고 싶네요"
        ,"추천하고 싶은 영화 입니다."
        ,"글쎄요"
        ,"별로예요"
        ,"생가보다 지루하네요"
        ,"연기가 어색해요"
        ,"재미없어요"  ]
#
# 1 긍정, 0 부정
classes = np.array([1, 1, 1, 1, 1, 0, 0, 0, 0, 0])
token = Tokenizer()
token.fit_on_texts(docs)
x = token.texts_to_sequences(docs) # 단어들에 대해서 index 값을 갖게 한 것ㅇ
#입력 데이터 사이즈 맞추는 패딩  차원수 .. 입력 데이터대한 사이즈를 맞춰주는것
paded_x = pad_sequences(x, 4)
#임베딩 단어수
word_size  = len(token.word_index)+1 # 문장들의 길이를 맞춰 주는 것
from keras.models import Sequential
from keras.layers import Embedding
from keras.layers import Flatten
from keras.layers import Dense

model = Sequential()
model.add(Embedding(word_size, 8, input_length=4))
model.add(Flatten())
model.add(Dense(1, activation='sigmoid'))
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['acc'])
model.fit(paded_x, classes, epochs=20)
print('acc : %4.f' %(model.evaluate(paded_x, classes)[1]))


