import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import openpyxl



def fn_dataset(data, seq):
    seq =seq+1
    result=[]
    for i in range(len(data)-seq):
        result.append(data[i : i+seq])
    return  result


def fn_normalize(data):
    normalize_data = []
    try:
        for row in data:
            normalize_window = [((float(p)/float(row[0]))-1)for p in row]
            normalize_data.append(normalize_window)
    except Exception as e:
        print(str(e))
    return np.array(normalize_data)

def fn_data_split(data, train_ratio):
    row = int(round(data.shape[0] * train_ratio))
    train  = data[:row, :]
    train = np.nan_to_num(train)
    x_train = train[:, :-1]
    x_train = np.reshape(x_train, (x_train.shape[0], x_train.shape[1],1))
    y_train = train[:,-1]

    x_test = data[row:,:-1]
    x_test = np.reshape(x_test, (x_test.shape[0], x_test.shape[1],1))
    y_test = data[row:, -1]

    return x_train, y_train, x_test, y_test
def fn_show(y_data, y_hat):
    fig  = plt.figure(facecolor='white',figsize=(20,10))
    ax = fig.add_subpot(111)
    ax.plot(y_data, label='True')
    ax.plot(y_hat, label = 'Prediction')
    ax.legnd()
    plt.show()

data = pd.read_excel('./005930_19950101_20220606.xlsx')
close =data['Close'].values
seq_length =50
dataset = fn_dataset(close, seq_length)
dataset = fn_normalize(dataset)
x_train, y_train, x_test, y_test = fn_data_split(dataset, 0.9)
print(x_train)

from keras.models import  Sequential
from keras.layers import LSTM, Dense
model = Sequential()
model.add(LSTM(50, return_sequences=True, input_shape=(50,1)))
model.add(LSTM(64, return_sequences=False))
model.add(Dense(1, activation='linear'))
model.compile(loss='mse', optimizer='rmsprop')
print(model.summary())
model.fit(x_train, y_train
          ,validation_data=(x_test, y_test)
          ,batch_size=10
          , epochs=5)
model.save('samsung.model')
y_pred = model.predict(x_test)

dataset = fn_dataset(data, seq_length)
print(dataset.head())