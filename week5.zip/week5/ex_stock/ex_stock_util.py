# import FinanceDataReader as fdr
# import matplotlib.pyplot as plt
# import pandas as pd
# import openpyxl
#
#
# # 주식 정보 엑셀저장
#
# def fn_get_stock(p_code, p_start, p_end):
#     stock = fdr.DataReader(p_code, p_start, p_end)
#     print(stock.head())
#     stock = stock.reset_index()  # 데이트를 index로 변환
#
#     seq = stock['Date'].dt.strftime('%Y-%m-%d')  # 데이터 시간 정보는 없앰
#     content = stock[['Date', 'Open', 'High', 'Low', 'Close', 'Volume', 'Change']].astype(str)
#     content['Date'] = seq
#     content = content[['Date', 'Open', 'High', 'Low', 'Close', 'Volume', 'Change']]
#     file_nm = '{0}_{1}_{2}.xlsx'.format(p_code, p_start.replace('-', ''), p_end.replace('-', ''))
#     writer = pd.ExcelWriter(file_nm, engine='openpyxl')
#     content.to_excel(writer, 'Sheet1')
#     writer.save()
#
#
# from datetime import datetime
# from dateutil.relativedelta import relativedelta
#
#
# # 이동 평균선(5일, 20일, 60일, 120일)
# def fn_avg_line(code='005930'):
#     # 올해년도
#     lastyear = datetime.now() + relativedelta(years=-1)
#     print(str(datetime.now().date()))
#     user_code = fdr.DataReader(code, str(lastyear.date()), str(datetime.now().date()))
#     new_user_code = user_code[user_code['Volume'] != 0]
#     # avg
#     ma5 = new_user_code['Close'].rolling(window=5).mean()
#     ma20 = new_user_code['Close'].rolling(window=20).mean()
#     ma60 = new_user_code['Close'].rolling(window=60).mean()
#     ma120 = new_user_code['Close'].rolling(window=120).mean()
#
#     new_user_code.insert(len(new_user_code.columns), 'MA5', ma5)
#     new_user_code.insert(len(new_user_code.columns), 'MA20', ma20)
#     new_user_code.insert(len(new_user_code.columns), 'MA60', ma60)
#     new_user_code.insert(len(new_user_code.columns), 'MA120', ma120)
#
#     plt.plot(new_user_code.index, new_user_code['Close'], label='Close')
#     plt.plot(new_user_code.index, new_user_code['MA5'], label='MA5')
#     plt.plot(new_user_code.index, new_user_code['MA20'], label='MA20')
#     plt.plot(new_user_code.index, new_user_code['MA60'], label='MA60')
#     plt.plot(new_user_code.index, new_user_code['MA120'], label='MA120')
#
#     plt.title(code)
#     plt.legend(loc='best')
#     plt.grid()
#     plt.show()
#
#
# if __name__ == '__main__':
#     fn_avg_line('AAPL')

import FinanceDataReader as fdr
import pandas as pd
import matplotlib.pyplot as plt


# 주식 정보 엑셀저장
def fn_get_stock(p_code, p_start, p_end):
    stock = fdr.DataReader(p_code, p_start, p_end)
    # print(stock.head())
    stock = stock.reset_index()
    seq = stock['Date'].dt.strftime('%Y-%m-%d')
    content = stock[['Date', 'Open', 'High', 'Low', 'Close', 'Volume', 'Change']].astype(str)
    content['Date'] = seq
    content = content[['Date', 'Open', 'High', 'Low', 'Close', 'Volume', 'Change']]
    file_nm = '{0}_{1}_{2}.xlsx'.format(p_code, p_start.replace('-', ''), p_end.replace('-', ''))
    writer = pd.ExcelWriter(file_nm, engine='openpyxl')
    content.to_excel(writer, 'Sheet1')
    writer.save()


from datetime import datetime
from dateutil.relativedelta import relativedelta


# 이동 평균선(5일, 20일, 60일, 120일)
def fn_avg_line(code='005930'):
    # 올해 년도
    lastyear = datetime.now() + relativedelta(years=-1)
    # print(str(datetime.now().date()))
    user_code = fdr.DataReader(code, str(lastyear.date()), str(datetime.now().date()))
    new_user_code = user_code[user_code['Volume'] != 0]
    # avg
    ma5 = new_user_code['Close'].rolling(window=5).mean()
    ma20 = new_user_code['Close'].rolling(window=20).mean()
    ma60 = new_user_code['Close'].rolling(window=60).mean()
    ma120 = new_user_code['Close'].rolling(window=120).mean()
    new_user_code.insert(len(new_user_code.columns), 'MA5', ma5)
    new_user_code.insert(len(new_user_code.columns), 'MA20', ma20)
    new_user_code.insert(len(new_user_code.columns), 'MA60', ma60)
    new_user_code.insert(len(new_user_code.columns), 'MA120', ma120)
    plt.plot(new_user_code.index, new_user_code['Close'], label='Close')
    plt.plot(new_user_code.index, new_user_code['MA5'], label='MA5')
    plt.plot(new_user_code.index, new_user_code['MA20'], label='MA20')
    plt.plot(new_user_code.index, new_user_code['MA60'], label='MA60')
    plt.plot(new_user_code.index, new_user_code['MA120'], label='MA120')
    plt.title(code)
    plt.legend(loc='best')
    plt.grid()
    plt.show()
if __name__ == '__main__':
    fn_avg_line('AAPL')
# 005930 삼성
# fn_get_stock('005930', '1995-01-01', '2022-06-06')
