from keras.models import load_model
from ex_stock_util import *
from ex_stock_lstm_1 import *
import pandas as pd
model = load_model('samsung.model')
print(model.summary())

fn_get_stock('005930', '2022-03-25', '2022-06-07')
data = pd.read_excel('./005930_20220325_20220607.xlsx', engine='openpyxl')
data = data['Close']
# dataset = fn_dataset(data, 50)
dataset = fn_nomalize([data])
y_pred = model.predict([dataset])
print('마지막날:', dataset[0][-1])
print('내일예측:', y_pred)