#pip install python-telegram-bot


#pip install python-telegram-bot
#
# TOKEN = '5325306310:AAGTDAD70x7eZ7zq0S0ihY5MYpuPGZb966c'
#
# from telegram.ext import Updater
# from telegram.ext import MessageHandler, Filters, CommandHandler
#
# updater = Updater(token=TOKEN, use_context=True)
#
# def fn_echo(update, context):
#     user_id = update.effective_chat.id
#     user_text = update.message.text
#     print(user_text)
#     context.bot.send_message(chat_id=user_id, text='hi')
#
# def fn_diary(update, context):
#     user_id = update.effective_chat.id
#     user_text = update.message.text
#     print(user_text)
#     msg = '일기를 쓰겠습니다.'
#     context.bot.send_message(chat_id=user_id, text='msg')
#
# echo_handler = MessageHandler(Filters.text & (~Filters.command), fn_echo)
# updater.dispatcher.add_handler(echo_handler)
#
# updater.dispatcher.add_handler(CommandHandler('diary', fn_diary))
# updater.start_polling(timeout=3, clean=True)
# updater.idle()


#pip install python-telegram-bot
import datetime
import os
import shutil

TOKEN = '5325306310:AAGTDAD70x7eZ7zq0S0ihY5MYpuPGZb966c'

from telegram.ext import Updater
from telegram.ext import MessageHandler, Filters, CommandHandler

updater = Updater(token=TOKEN, use_context=True)

def fn_echo(update, context):
    user_id = update.effective_chat.id
    user_text = update.message.text
    print(user_text)
    context.bot.send_message(chat_id=user_id, text='hi')



    # 현재위치 파악
    print(os.getcwd())
    filePath = os.getcwd()

def fn_write_diary(msg):
    now = datetime.datetime.now()
    formattedDate = now.strftime("/%Y%m%d_diary.txt")
    print(formattedDate)

    # 파일만들곳 경로 만들기
    fileNm = os.getcwd() +'/diary'+ formattedDate
    folder = './diary'
    print(fileNm)

    if not os.path.exists((folder)):
        # 폴더 생성
        os.makedirs(folder)
    # 파일 이동
    f = open(fileNm, 'a')
    f.write(msg)


def fn_diary(update, context):
    user_id = update.effective_chat.id
    user_text = update.message.text
    print(user_text)
    msg = user_text.replace('/diary','')
    fn_write_diary(msg)
    context.bot.send_message(chat_id=user_id, text="일기를 작성하하시오")

# 기본 메세지
echo_handler = MessageHandler(Filters.text & (~Filters.command), fn_echo)
updater.dispatcher.add_handler(echo_handler)

# /diary 텍스트 잇을때 실행
updater.dispatcher.add_handler(CommandHandler('diary', fn_diary))


updater.start_polling()
updater.idle()


