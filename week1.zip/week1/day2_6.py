import os


path = '/home/pc11/Downloads'
# 디폴트 top-dwon : 상위->하위로
# topsown = False : 하위에ㅐ서-> 상위로
# for root, dirs, files in os.walk(path):
for root, dirs, files in os.walk(path, topdown=False):
    print(root, dirs, files)

