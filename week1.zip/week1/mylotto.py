# 입력 받은 수 만큼
# 로또 번호 생성해 주세요
a=[1,4,6]
print(len(a))
import random
num = int(input("몇개 만들까요??"))
arr = set()
for j in range(num):
    while len(arr) < 6 :
        mylotto = random.randint(1, 45)
        arr.add(mylotto)
    print(arr)

    arr=set()
