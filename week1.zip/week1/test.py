import day2_9
from day2_9 import Rectangle as Rec

print(day2_9.Rectangle.printCnt())
print(Rec.printCnt())

rec = Rec(100, 100)
print(rec.isSquare(10,10))
