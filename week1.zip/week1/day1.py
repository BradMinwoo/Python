print('hi')

a = '안녕하세요'
print(a)
# 문자열 곱하기
print(a*10)
a = '''hi
hello
안녕
'''
print(a)
# 문자열 나누기(split)
b = 'Life is too short'
c = b.split()  #매개변수 없으면 공백으로 자름
print(c)
d = "a:b:c:d"
f = d.split(':')
print(f)

# 입력 받기
num=int(input('숫자를 입력하세요 : '))
print(num)
if num<10 :
    print('10보다 작음')
elif num == 100:
    print('100 이닸')
else:
    print('100보다 커')