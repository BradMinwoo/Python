# 동적배열 list
a = []
b = [1, 2, 3]
c = [1, 2, 'list', 'is']
d = [1, 2, [3, 4]]
# 리스트 인덱스 -1 : 마지막 요소 -2: 뒤에서 두번째
# 중첩리스트d[2][0] <-d의 3번째 요소의 0번째 요소
print(c[-1])
print(d[2][0])
# 슬라이스
# [처음인덱스 : 마지막 인덱스+1]
print(d[1:3])
f = ['This','is','a','book','is']
print(f.count('is'))
#리스트 곱
print(d*100)
#for 문 style 1
arr = ['one','two','three']
for i in arr:
    print(i)
#for 문 style 2 : index, value 둘다 필요할때
for i, v in enumerate(arr):
    print(i,'번째:',v)
#for문 style 3
for i in range(1, 5):
    print(i, end=',') #모아서 프린트 하고 싶을때

# 입력 받는 수 만큼 hi를 출력하시오
# hi = int(input('숫자를 입력하시오:'))
# for i in range(hi):
#     print('hi')

import  random
#1~10사이 정수값 반환
num = random.randint(1, 10)
print(num)
while True:
    user_num = int(input('1~10  임의의 수를 맞춰 보세요 : '))
    if num == user_num:
        print("정답!!!!")
        break
    elif user_num > num:
        print('더 작게')
    elif user_num < num:
        print('더크게')
    else:
        print('달라용')
