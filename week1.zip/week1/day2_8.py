import  shutil
import os
from_ ='bot.py'
to_ = './backup'
if not os.path.exists(to_):
    # 폴더 생성
    os.makedirs(to_)
# 파일 이동
shutil.move(from_, to_)