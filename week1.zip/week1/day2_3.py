import os
import time

print(os.getcwd()) #현재 위치
# fileNm = 'delay.txt'
fileNm = 'delay.txt'
if os.path.exists(fileNm):
    #파일 시간
    print(time.ctime(os.path.getmtime(fileNm)))
    #파일 용량
    print(os.path.getsize(fileNm),'byte')
    print(os.path.getsize(fileNm)/1024,'killo byte')
    #파일이면
    if os.path.isfile(fileNm):
        os.remove(fileNm) #파일삭제
    if os.path.isdir(fileNm):
        os.rmdir(fileNm)
    print('삭제됨')