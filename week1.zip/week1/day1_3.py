#set 중복이 없는
myset = {1,3,4,5,1} #중괄호
print(myset)
test={}
print(type(test))
myset2 = set()
print(type(myset2))
# 요소추가
myset2.add(10)
# 여러개 추가

myset2.update({4,99,10})
# 하나만 삭제
print(myset2)
myset2.remove(10)
print(myset2)
# 모두 삭제
myset2.clear()