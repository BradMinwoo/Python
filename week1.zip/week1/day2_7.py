#스케쥴러러
# pip install apscheduler
from apscheduler.schedulers.blocking import BlockingScheduler
import datetime
#실행함수
def exec_interval():
    print('interval')
    print(datetime.datetime.now())
def exec_cron(a,b):
    print('cron')
    print(datetime.datetime.now())
sched = BlockingScheduler()
#interval
#interval 잡 등록
sched.add_job(exec_interval, 'interval', seconds=10)
#corn 잡 등록
sched.add_job(exec_cron,'cron', hour=19, minute=9, args=['a','b'])
#시작
sched.start()