import os


# root = os.getcwd()
root = '/'
#/는 오나전 최상위 에 잇는 폴더 명만 가져옴.
searchNm = input('찾고 싶은파일명 : ')
#해당 위치의 파일 정보 가져오기
files = os.listdir(root)
print(files)

for file in files:
    # print(file)
    # 경로 + 파일 명
    #
    path = os.path.join(root, file)
    # print(path)
    if searchNm in file:
        check = input('이걸 찾나?:'+path+'?(y/n)')
        if check =='y':
            break
