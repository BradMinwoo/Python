from sklearn.linear_model import Perceptron

X = ([[0,0]  ,[1,0]  ,[0,1]  ,[1,1]])
# Y= ([0,0,0,1]) #AND
# Y= ([0,1,1,1]) #OR
Y= ([0,1,1,0]) #XOR percetron 한계 구현할수 없음.
model = Perceptron(tol = 1e-3, random_state=0)
model.fit(X,Y)


print(model.predict(X))