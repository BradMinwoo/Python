import keras
import numpy

model = keras. models.load_model('pima.model')
print(model.summary())

dataset = numpy.loadtxt('../week3/data/pima-indians-diabetes.csv', delimiter=',')
X = dataset[:, 0:8]
Y = dataset[:,8]
print(model.evaluate(X, Y)[1])
