import  numpy as np

X = np.array([[0,0]
              ,[1,0]
              ,[0,1]
              ,[1,1]])
# Y= np.array([-1,-1,-1,1]) #AND
# Y= np.array([-1,1,1,1]) #OR 연산
Y= np.array([-1,1,1,-1]) #XOR 연산

W = np.array([1.,1.,1.]) #bais, w1,w2 <-초깃값

def forward(x):
    return np.dot(x, W[1:])+W[0]

def fn_step(x):
    return  np.where(forward(x)>0,1,-1)
print('before traing : ',W)
lr = 0.01
for epoch in range(50):
    for x_val , y_val in zip(X, Y):
        update = lr *(y_val - fn_step(x_val))
        W[1:] += update *x_val
        W[0] += update
        print(W[0], W[1],W[2])
print('after training : ', W)
for i, v in enumerate(X):
    print('input : ', v)
    print('ouput : ',fn_step(v))