import numpy as np
import matplotlib.pyplot as plt

def fn_step(x):
    if x >= 0:
        return 1.0
    else:
        return 0.0


x = np.linspace(-8, 8 , 100)
sig=[]
for i in x:
    sig.append(fn_step(i))
plt.plot(x, sig)
plt.show()