# 대상 URL
# 목표 데이터 설명
# ----------------(.txt 파일)
# 수집 자료 (.py 파일)
from selenium import webdriver
import time
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup

url = 'https://www.naver.com/'
driver = webdriver.Chrome('./chromedriver')
driver.implicitly_wait(3)
driver.get(url)
time.sleep(1)
driver.find_element_by_id('query').send_keys('갈마동 맛집')
time.sleep(1)
search = driver.find_element_by_css_selector('button.btn_submit')
search.click()
time.sleep(3)
try:
    cnt=2
    pagedown = 1
    body = driver.find_element_by_tag_name('body')
    while pagedown < cnt:
        body.send_keys(Keys.PAGE_DOWN)
        time.sleep(2)
        pagedown += 1
except Exception as e:
    print(str(e))
driver.find_element_by_css_selector('.api_more_wrap').click()
# _pcmap_list_scroll_container > ul > li:nth-child(1)
# restaurantList = driver.find_elements_by_css_selector('#_pcmap_list_scroll_container > ul > li')
time.sleep(5)
# //*[@id="_pcmap_list_scroll_container"]/ul/li[1]/div[1]/a/div[1]/div/span[1]
soup = BeautifulSoup(driver.page_source, 'html.parser')
print(soup.prettify())
div = soup.select_one('#_pcmap_list_scroll_container')
lis = div.find_all('li')
for li in lis:
    print(li)
#
# temp_list = []
# time.sleep(2)
# count = 0
# total = len(restaurantList)
# print(total)
# for restaurant in restaurantList:
#     count += 1
#     print(count)
#     restaurantName = restaurant.find_elements_by_css_selector(".OXiLu")
#     foodType = restaurant.find_elements_by_css_selector("._39UbY")
# temp_list.append([restaurantName, foodType])
# print(temp_list)
#
