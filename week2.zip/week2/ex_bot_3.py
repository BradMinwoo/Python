#pip install python-telegram-bot

TOKEN = '5325306310:AAGTDAD70x7eZ7zq0S0ihY5MYpuPGZb966c'

from telegram.ext import Updater
from telegram.ext import MessageHandler, Filters, CommandHandler
import datetime
import os
from day6_practice import fn_search_name

updater = Updater(token=TOKEN, use_context=True)

def fn_echo(update, context):
    user_id = update.effective_chat.id
    user_text = update.message.text
    print(user_text)
    context.bot.send_message(chat_id=user_id, text='hi')

def fn_diary(update, context):
    user_id = update.effective_chat.id
    user_text = update.message.text
    print(user_text)
    context.bot.send_message(chat_id=user_id, text="일기를 작성하겠어")
    fn_save_diary(user_text)

def fn_save_diary(message):
    now = datetime.datetime.now()
    fileNm = now.strftime('%Y-%m-%d')
    path = os.getcwd() + "/diary/"
    st = open(path + fileNm, 'a')
    st.write(message[6:] + "\n")
    st.close()

def memmem(update, context):

    user_id = update.effective_chat.id
    user_text = update.message.text
    print(user_text)
    re = fn_search_name(user_text)
    for i in re:
        context.bot.send_message(chat_id=user_id, text=i[0])
# 기본 메세지
echo_handler = MessageHandler(Filters.text & (~Filters.command), fn_echo)
updater.dispatcher.add_handler(echo_handler)
updater.dispatcher
# /diary 텍스트 잇을때 실행
updater.dispatcher.add_handler(CommandHandler('diary', fn_diary))
updater.dispatcher.add_handler(CommandHandler('member', memmem))

def save_photo(update, context):
    dir='./'
    imgNm = 'save_img.png'
    file_path= os.path.join(dir, imgNm)
    bot = context.bot
    photo = bot.getFile(update.message.photo[-1].file_id)
    photo.download(file_path)
    update.message.reply_text('photo saved')

photo_handler = MessageHandler(Filters.photo, save_photo)
updater.dispatcher.add_handler(photo_handler)
updater.start_polling(timeout=3, clean=True)
updater.idle()