import os
import urllib.request
url='https://image.bugsm.co.kr/album/images/500/1745/174521.jpg'
savaNm = 'hunt2.jpg'
print(os.getcwd())
urllib.request.urlretrieve(url, os.getcwd()+"/"+savaNm)
print('저장됨')
