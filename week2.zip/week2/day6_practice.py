import cx_Oracle
conn = cx_Oracle.connect('study','study','localhost:1521/XE')
print(conn.version)



# name = input('고객 이름을 입력하세요 : ')

def fn_search_name(name):
    memberList =[]
    with conn:
        cur = conn.cursor()
        sql = """select mem_id, mem_mail, mem_job, mem_mileage
                from member
                where mem_name like '%'||:word||'%'
                """
        rows = cur.execute(sql, {'word': name})
        # de = rows.description
        colums = [d[0] for d in rows.description]
        for i, v in enumerate(rows):
            print(v)
            memberList.append(v)
            print('멤id:' +memberList[i][0])
            print('멤이메일:' +memberList[i][1])
            print('멤직업:' +memberList[i][2])
            print('멤마일리:' +str(memberList[i][3]))
    return memberList
if __name__ == '__main__':
    fn_search_name('김은대')
# 터미널에서 고객 이름을 입력 받아 아이디, 이메일, 직업, 마일리지 리턴 함수 작성