# -*- coding:utf-8 -*-
# utf-8로
from bs4 import BeautifulSoup

import requests
movie_list = []
for j in range(40):
    url = 'https://www.inven.co.kr/board/lol/2771'
    resp = requests.get(url)
    # print('status : ', resp.status_code)
    soup = BeautifulSoup(resp.text, 'html.parser')
    # print(resp.text)
    # print("구분"+ ("=" * 100))
    # print(soup.prettify()) # 구조화 출력

    div = soup.select_one('.board-list')
    trs = div.find_all('tr')

    for i, v in enumerate(trs):
        if i > 1:
            if v.find('a'):
                try:
                    no = v.select_one('.num').text
                except Exception as e:
                    no = v.select_one('.num').text
                try:
                    name = v.select_one('.layerNickname').text
                except Exception as e:
                    print(str(e))
                title = v.find('.subject-link').text
                img_url = v.find('.subject-link').attrs['href']
                date = v.select_one('.date').text
                movie_list.append([no, name, title, img_url, date])
for i in movie_list:
    print(i)
# DB에서도 읽을수 있는 형식
import csv
with open('movie.csv', 'w', encoding='utf8') as f:
    write = csv.writer(f, delimiter='|', quotechar='"')
    for i in movie_list:
        write.writerow(i)