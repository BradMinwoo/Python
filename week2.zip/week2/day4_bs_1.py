# -*- coding:utf-8 -*-
# uft-8로
from bs4 import BeautifulSoup

import requests
url= 'https://movie.naver.com/movie/sdb/rank/rmovie.naver?sel=pnt&date=20220516&page='
movie_list = []
for i in range(0, 40):
    path = url + str(i+1)
    # print(path)
    resp = requests.get(path)
    # print('status : ', resp.status_code)
    soup= BeautifulSoup(resp.text, 'html.parser')
# # print(resp.text)
# # print(soup.prettify()) #구조화 출력
#

    div = soup.select_one('.list_ranking')
    trs = div.find_all('tr')


    for i, v in enumerate(trs):
        if i >0:
            # print(v)
            if v.find_all('a'):
               try:
                    # no = v.select_one('.ac > img')['src']
                    no = v.select_one('td:first-child > img')['alt']

                    updown = v.select_one('.point').text
                    # [0].attrs['alt']

                    title = v.find('a').text
                    img_url = v.find('a').attrs['href']
                    score = v.select_one('td.range.ac').text
                    movie_list.append([no, title, img_url, updown, score])
               except Exception as e:
                    no = v.select_one('td.order ').text
                    updown = v.select_one('.point').text
                    title = v.find('a').text
                    img_url = v.find('a').attrs['href']
                    score = v.select_one('td.range.ac').text
                    movie_list.append([no, title, img_url, updown, score])

               finally:
                   pass



    # if문 써서 하기

import  csv
with open('movie.csv', 'w', encoding='utf-8') as f:
    write = csv.writer(f, delimiter='|', quotechar='"')

    for i in movie_list:
        write.writerow(i)
print(movie_list)