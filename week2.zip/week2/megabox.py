from selenium import webdriver
import time
from selenium.webdriver.common.keys import Keys
import util

from bs4 import BeautifulSoup
#관심 주제 : 영화를 좋아해서 영화 리스트를 크롤링 하고
# 추가적으로 영화를 본 사람들의 평점과 관람평을 크롤링함.


url='https://www.megabox.co.kr/movie'
driver = webdriver.Chrome('./chromedriver')
driver.implicitly_wait(3)
driver.get(url)


#영화 리스트 저장

try:
    cnt = 20
    pagedowns = 1
    body = driver.find_element_by_tag_name('body')

    button = driver.find_element_by_id('btnAddMovie')
    button.click()
    while pagedowns < cnt:
        body.send_keys(Keys.PAGE_DOWN)
        time.sleep(1)
        pagedowns+=1
        button.click()
except Exception as e:
    print(str(e))

temp_list= []
html = driver.page_source
driver.close()
soup = BeautifulSoup(html, 'html.parser')
lis = soup.select('#movieList li')
print(lis)
for li in lis:

    rank = li.select_one('.rank').text
    title = li.select_one('.tit-area').text
    rate = li.select_one('.rate').text
    date = li.select_one('.date').text
    code = li.select_one('.button.btn-like').attrs['data-no']

    temp_list.append([rank, title,rate,date,code])
print(temp_list)


#관람 후기 저장
driver = webdriver.Chrome('./chromedriver')
comm_list = []
for i in temp_list:
    a= i[4]
    comm_add = 'https://www.megabox.co.kr/movie-detail/comment?rpstMovieNo='+a
    driver.get(comm_add)
    try:
        for i in range(1, 10):
            comm_title = driver.find_element_by_css_selector("#contents > div.movie-detail-page > div.movie-detail-cont > p.title").text
            comm_id = driver.find_element_by_css_selector(("#contentData > div > div.movie-idv-story > ul > li:nth-child("+str(i+1)+") > div.story-area > div.user-prof > p")).text
            comm_rate=driver.find_element_by_css_selector("#contentData > div > div.movie-idv-story > ul > li:nth-child("+str(i+1)+") > div.story-area > div.story-box > div > div.story-cont > div.story-point").text
            comm_ment=driver.find_element_by_css_selector("#contentData > div > div.movie-idv-story > ul > li:nth-child("+str(i+1)+") > div.story-area > div.story-box > div > div.story-cont > div.story-txt").text
            comm_list.append([comm_title, comm_id, comm_rate,comm_ment])
    except Exception as e:
        pass
print(comm_list)



with open('Megabox_link.txt', "wt", encoding="utf-8") as f:
    for item in temp_list :
        f.write(str(item)+'\n')

    for comment in comm_list:
        f.write(str(comment) + '\n')