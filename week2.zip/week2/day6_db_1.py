# pip install cx_Oracle
import cx_Oracle
conn = cx_Oracle.connect('study','study','localhost:1521/XE')
print(conn.version)

memberList =[]
with conn: # with를 쓰면 close를 안해도 자동으로 닫힘. (원래 : cursor는 닫아줘야함, cursor는 휘발성)
    cur = conn.cursor()
    sql = """select *
            from member
            where mem_name like '%'||:word||'%'
            """
    rows = cur.execute(sql, {'word': '김'})
    # de = rows.description
    colums = [d[0] for d in rows.description]
    for i in rows:
        print(i)
        row = list(i)
        memberList.append(i)

print(memberList)


#터미널에서 고객 이름을 입력 받아 아이디, 이메일, 직업, 마일리지 리턴 함수 작성
